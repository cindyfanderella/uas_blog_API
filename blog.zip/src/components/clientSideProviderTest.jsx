"use client"

const ClientSideProviderTest = ({children}) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default ClientSideProviderTest